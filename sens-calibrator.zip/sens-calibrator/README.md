# Sens Calibrator

A step-by-step sensitivity calculator. Answers phone name, usage duration,
screen refresh rate, and play style, then outputs tuned sensitivity values
(General, Red Dot, 2x, 4x, AWM, Free Look) on a 0–200 scale.

## Structure

```
sens-calibrator/
├── index.html      # page structure, one step per screen
├── css/style.css    # styling and theme
├── js/script.js      # step navigation + calculation logic
└── README.md
```

## Run locally

No build step needed — it's static HTML/CSS/JS.

- Open `index.html` directly in a browser, or
- Serve it with any static server, e.g.:
  ```
  npx serve .
  ```

## Deploy on Railway

1. Push this folder to a GitHub repo.
2. In Railway: **New Project → Deploy from GitHub repo** → select the repo.
3. Since this is a static site, add a simple start command so Railway serves it, e.g. in Railway's settings set:
   - Build command: *(none needed)*
   - Start command: `npx serve . -p $PORT`
4. Railway will give you a public URL once deployed.

## Customize

- Colors/theme: edit the CSS variables at the top of `css/style.css`.
- Sensitivity formula: edit `baseRanges` and the adjustment logic in `js/script.js`.
- Steps/questions: edit the `.step` blocks in `index.html`.
