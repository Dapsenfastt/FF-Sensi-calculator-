let current = 0;
const total = 5;
let playStyle = 'balanced';

function renderDots(){
  const dotsEl = document.getElementById('dots');
  dotsEl.innerHTML = '';
  for(let i=0;i<total;i++){
    const d = document.createElement('div');
    d.className = 'dot' + (i===current ? ' active' : i<current ? ' done' : '');
    dotsEl.appendChild(d);
  }
}

function showStep(i){
  document.querySelectorAll('.step').forEach(s=>s.classList.remove('active'));
  document.querySelector('.step[data-step="'+i+'"]').classList.add('active');
  renderDots();
}

function next(){
  if(current < total-1){ current++; showStep(current); }
}
function back(){
  if(current > 0){ current--; showStep(current); }
}
function restart(){
  current = 0; showStep(current);
}

document.getElementById('styleGroup').addEventListener('click', e=>{
  const btn = e.target.closest('button');
  if(!btn) return;
  playStyle = btn.dataset.val;
  document.querySelectorAll('#styleGroup button').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
});

const baseRanges = {
  aggressive:{general:190, reddot:180, x2:130, x4:90,  awm:70, freelook:190},
  balanced:  {general:155, reddot:145, x2:105, x4:70,  awm:50, freelook:155},
  passive:   {general:120, reddot:115, x2:75,  x4:55,  awm:40, freelook:120}
};

function clamp(v){ return Math.max(0, Math.min(200, Math.round(v))); }

function finish(){
  const months = parseInt(document.getElementById('usage').value, 10);
  const refresh = parseInt(document.getElementById('refresh').value, 10);
  const phoneName = document.getElementById('phoneName').value.trim() || 'your phone';

  let usageAdj = 0;
  if(months < 6) usageAdj = 5;
  else if(months <= 12) usageAdj = 2;
  else if(months <= 24) usageAdj = 0;
  else usageAdj = -5;

  let refreshAdj = 0;
  if(refresh === 60) refreshAdj = -10;
  else if(refresh === 90) refreshAdj = 0;
  else if(refresh === 120) refreshAdj = 10;
  else if(refresh === 144) refreshAdj = 15;

  const base = baseRanges[playStyle];
  const totalAdj = usageAdj + refreshAdj;

  document.getElementById('r-general').textContent = clamp(base.general + totalAdj);
  document.getElementById('r-reddot').textContent = clamp(base.reddot + totalAdj);
  document.getElementById('r-2x').textContent = clamp(base.x2 + totalAdj*0.7);
  document.getElementById('r-4x').textContent = clamp(base.x4 + totalAdj*0.5);
  document.getElementById('r-awm').textContent = clamp(base.awm + totalAdj*0.4);
  document.getElementById('r-freelook').textContent = clamp(base.freelook + totalAdj);
  document.getElementById('r-phone').textContent = phoneName;

  next();
}

renderDots();

function copyAcct(){
  const acct = document.getElementById('tipAcct').textContent;
  const btn = document.getElementById('copyBtn');
  navigator.clipboard.writeText(acct).then(()=>{
    const original = btn.textContent;
    btn.textContent = 'Copied!';
    setTimeout(()=>{ btn.textContent = original; }, 1500);
  }).catch(()=>{
    btn.textContent = 'Copy failed — copy manually';
  });
}
